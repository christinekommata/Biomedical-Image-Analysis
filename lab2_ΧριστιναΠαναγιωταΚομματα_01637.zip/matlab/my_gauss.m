%sunarthsh gia thn gaussianh 

function [out]=my_gauss(sigma, rows, cols)
yc=cols/2;
xc=rows/2;
for x=1:rows
    for y=1:cols 
        out(x,y)=(1/(2*pi*sigma^2))*exp(-((x-xc)^2/rows+(y-yc)^2/cols)/(2*sigma^2));
        
    end
end
end 