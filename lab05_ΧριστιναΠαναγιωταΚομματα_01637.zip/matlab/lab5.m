clear all; close all;
img1=imread('image268x324.png');
hist_img1=my_hist(255-img1);
figure;  bar(hist_img1);
title(' my histogram');

figure;imhist(img1);
title('histogram');
ylim([0 3500]);
[counts,bins]=imhist(img1);

%exercise 2
img2=imread('mri221x279.png');
hist_img2=my_hist(img2);
[rows2,cols2]=size(img2);
figure; imshow(img2);
const=255/(rows2*cols2);
for i=1:rows2
    for j=1:cols2
        hist_eq(i,j)=const*sum(hist_img2(1:(img2(i,j)+1)));
        
    end
end
        
figure;imshow(hist_eq,[]);

img3=histeq(img2);
figure; imshow(img3);

%% %exercise 3

q=0:255/3:255;
cols_q=size(q,2);
[rows,cols]=size(img1);

for i=1:rows
    for j=1:cols
          for k=1:cols_q-1
              if img1(i,j)>=q(k) && img1(i,j)>=q(k+1)
                  img_quantize(i,j)=(q(k)+q(k+1))/2;
              end
          end 
    end 
end

quant_A = imquantize(img1,q);
figure; imshow(quant_A,[]);
levels=multithresh(img1,3);
quant_B = imquantize(img1,levels);
figure; imshow(quant_B,[]);
