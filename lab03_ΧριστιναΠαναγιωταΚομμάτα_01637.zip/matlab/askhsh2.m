%askhsh 2 

img=imread('chest339x339.png');

img2=img+30; %increase brightness
img3=1.4*img; 
figure;
imshow(img)