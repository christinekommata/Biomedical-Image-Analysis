function [output] = normImage(input)
    % Image histogram normalization
    input = double(input); % Cast to double
    minvalue = min(min(input)); 
    maxvalue = max(max(input)); 
    output = uint8((input-minvalue)*100/(maxvalue-minvalue)); %// Cast back to uint8
end