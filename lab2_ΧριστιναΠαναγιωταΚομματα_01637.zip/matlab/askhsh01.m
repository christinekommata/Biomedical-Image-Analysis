%askhsh1
img=imread('image268x324.png');

noise_img=noise(img);
figure;
imshow(noise_img);
