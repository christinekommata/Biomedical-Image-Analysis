%askhsh5

img5=normalize(img,100,60,180,120);
figure; imshow(img5);
title('normalized square area of CT scan');