/*
  ------------------------------------------------------------
  ANSI C IMAGE PROCESSING TEMPLATE USING DIP LIBRARY
  by D.K. Iakovidis
  ------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "dip.h"			

unsigned char *translateImage(unsigned char **inputImage, int rows, int columns, int di, int dj);

int main(void)
{
     unsigned char *inputFilename = "image268x324.raw",
                   *outputFilename = "image268x324out.raw";
     int rows = 324, 
         columns = 268;
         
     unsigned char **inputImage, **outputImage;

     inputImage = allocateImage(rows, columns);     
     
     inputImage = loadImage(inputFilename, rows, columns);
     outputImage = translateImage(inputImage, rows, columns,10, 30 );
     saveImage(outputFilename, outputImage, rows, columns);    
     deallocateImage(inputImage, rows);
     deallocateImage(outputImage, rows);      

     return 0;
}


unsigned char *translateImage(unsigned char **inputImage, int rows, int columns, int di, int dj)
{
     int i,j;
     int ii, jj;
     unsigned char **outputImage = allocateImage(rows, columns);
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
         	
         	 outputImage[i][j] =0 ;
         	 ii=i+di;
         	 jj=j+dj;        	 
         	 
            if ((ii>=0) && (ii<rows) && (jj>=0) && (jj<columns)) outputImage[i][j] = inputImage[ii][jj];
         }
     }
     return outputImage;
}
