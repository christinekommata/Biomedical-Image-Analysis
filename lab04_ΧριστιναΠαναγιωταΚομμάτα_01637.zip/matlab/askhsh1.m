%askhsh1

mri=imread('mri221x279.png');
pet=imread('petGrey221x279');

fusedImage =(mri+pet)/2;
fusedImage =normImage(fusedImage);

figure;
imshow(fusedImage);
title('MRI+pet');
