% linear transformation: if c>1 and b>0, contrast and brightness increase

function [out]=transform(img,x1,y1,x2,y2,c,b)

    [rows,columns]=size(img);

% if I want to generate random coordinates for square area
% without defining them as parameters, I write:
    %x1=mod(255*rand(),rows);
    %y1=mod(255*rand(),columns);
    %x2=mod(255*rand(),rows);
    %y2=mod(255*rand(),columns);
       
    for i=1:rows
        for j=1:columns
            if (i>=x1) && (i<=x2) && (j>=y1) && (j<=y2)
            	out(i,j)=c.*img(i,j)+b;
                % if (i,j) are in square area, output is transformed img
            else
        		out(i,j)=img(i,j);
                % else, output is original image
            end
        end
    end

end