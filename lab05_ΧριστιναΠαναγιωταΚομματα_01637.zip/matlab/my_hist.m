function[h]=my_hist(I)

h=zeros(1,256);
[rows,cols]=size(I);

for i=1:rows
    for j=1:cols
        h(I(i,j)+1)= h(I(i,j)+1)+1;
    end
end






