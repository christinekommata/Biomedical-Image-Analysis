%askhsh 3

img=imread('image268x324.png');

%invert_img=255-img;
inv_img=Invert_img(img);
figure;
imshow(inv_img);