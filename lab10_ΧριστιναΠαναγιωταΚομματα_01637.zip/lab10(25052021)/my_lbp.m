function [out]=my_lbp(I,mask)
[rows, cols]=size(I);

for i=2:(rows-1)
    for j=2:(cols-1)
        
        lbp=0;
        for k=1:3
            for l=1:3 
                if (I(i,j)>I(i+k-2, j+l-2))
                    pattern(k,l)=1;
                else 
                    pattern(k,l)=0;
                end 
                pattern(k,l)=pattern(k,l)*mask(k,l);
                lbp=lbp+pattern(k,l);
            end
        end 
        out(i,j)=lbp;
    end
    
    
end

end