function [Gauss_img]=my_gauss(sigma, rows, columns)
xc=rows/2;
yc=columns/2;

for x=1:rows
    for y=1:columns
        Gauss_img(x,y)=(1/(2*pi*(sigma^2)))*exp(-((x-xc)^2+(y-yc)^2)/(2*sigma^2));
    end
end    