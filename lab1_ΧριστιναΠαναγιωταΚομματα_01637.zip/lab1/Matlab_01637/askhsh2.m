%askhsh2
img9=imread('image268x324.png');
figure;
imshow(img9);


%invert image
img10=255-img9;
figure;
imshow(img10);
