%askhsh4

img4=maxcross(img);
figure; imshow(img4);
title('marked max gray level of CT scan');
