img=imread('angioectasia-P2-6.png');
hsv=rgb2hsv(double(img));

figure; imshow(img);
figure; imshow(hsv,[]);
h=hsv(:,:,1);
s=hsv(:,:,2);
v=hsv(:,:,3);

lab=rgb2lab(double(img));

figure; imshow(img);
figure; imshow(lab,[]);
l=lab(:,:,1);
a=lab(:,:,2);
b=lab(:,:,3);

 figure; imshow(l,[]);
figure; imshow(a,[]);
figure; imshow(b,[]);
