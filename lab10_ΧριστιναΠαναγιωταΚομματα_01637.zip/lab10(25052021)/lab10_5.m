clear all;
folder='C:\Users\Lab10\wang\';
S1=dir(fullfile(folder,'*.jpg'));
C1=natsortfiles({S1.name});

for i=1:length(C1)
    str=fullfile(folder, C1{i});
    im=imread(str);
    
    R=im(:,:,1);
    G=im(:,:,2);
    B=im(:,:,3);
    
    im_hist(i,:)=[imhist(R)', imhist(G)', imhist(B)'];
      
    
end


 k=5;
 [cluster_idx, cluster_center]= kmeans(im_hist, k, 'distance', 'sqEuclidean');
 