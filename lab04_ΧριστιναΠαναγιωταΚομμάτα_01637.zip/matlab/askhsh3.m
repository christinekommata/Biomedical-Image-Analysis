%askhsh3
brain=imread('image268x324.png');
mask=imread('Mask.png');
[~,~]=size(brain);
[rows,columns]=size(mask);

%g
img1=and(brain,1-mask);
figure;
imshow(img1);

%d
img2=and(brain,mask);
figure;
imshow(img2);

%st
img3=and(brain,kernel);
figure;
imshow(img3);

