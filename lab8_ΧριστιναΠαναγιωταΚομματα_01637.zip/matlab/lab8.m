
img=imread('melanoma.jpg');
r=img(:,:,1);
g=img(:,:,2);
b=img(:,:,3);

figure; 
imshow(img);
title('melanoma')

figure; 
imshow(r);
title('R')

figure; 
imshow(g);
title('G')

figure; 
imshow(b);
title('B')

r=double(r);
g=double(g);
b=double(b);
gray_img=(r+g+b)/3;
figure; imshow(gray_img,[]);

gray_img2=rgb2gray(img);
figure; imshow(gray_img2,[]);