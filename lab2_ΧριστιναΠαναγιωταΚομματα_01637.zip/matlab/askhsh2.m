%askhsh2

rows=250;
cols=250;
s=4;

gauss_img= my_gauss(s, rows, cols);
gauss_img= normImage(gauss_img);
figure;
imshow(gauss_img);