%function for inverted image

function [out]= Invert_img(img)

     out=255-img;

end 