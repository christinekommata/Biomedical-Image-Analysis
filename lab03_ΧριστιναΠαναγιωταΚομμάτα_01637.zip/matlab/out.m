%askhsh5

img=imread('chest339x339.png');

function [out]= normalize (img,x1,x2,y1,y2)

[rows,columns]=size(img);
temp=imadjust (img);

for i=1:rows
    for j=1:columns 
        if (i>=x1) && (i<=x2) && (j>=y1) && (j<=y2)
            out(i,j)=temp(i,j);
        else
            out(i,j)=img(i,j);
        end
    end
end

end


