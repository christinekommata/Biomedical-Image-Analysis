%askhsh2
chest=imread('chest339x339.png');
[rows,columns] = size(chest);
blackWhite=zeros(339,339);


%ftiaxnw aspromavrh (b)
blackWhite(:,1:columns/2)=255;
figure;
imshow(blackWhite);

%a
seg=1-imbinarize(chest,0.67);
figure;
imshow(seg);

%g
img1=and(seg,255-blackWhite);
figure;
imshow(img1);

%d
img2=or(seg,255-blackWhite);
figure;
imshow(img2);

%e
img3=xor(seg,255-blackWhite);
figure;
imshow(img3);

%st
img4=not(seg,255-blackWhite);
figure;
imshow(img4);







