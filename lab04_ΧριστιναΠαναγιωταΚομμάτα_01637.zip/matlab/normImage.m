function [output] = normImage(input)

input=double(input);
minvalue = min(min(input));
maxvalue = max(max(input));
output = uint8((input-minvalue)*255/(maxvalue-minvalue));
end