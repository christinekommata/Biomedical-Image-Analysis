%askhsh 3 

img3=transform(img,100,60,180,120,1.2,30);
figure; imshow(img3);
title('linear transformation of a square area');
