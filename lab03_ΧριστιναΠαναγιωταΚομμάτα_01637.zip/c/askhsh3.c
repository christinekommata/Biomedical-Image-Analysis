/*
  ------------------------------------------------------------
  ANSI C IMAGE PROCESSING TEMPLATE USING DIP LIBRARY
  by D.K. Iakovidis
  ------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "dip.h"			

unsigned char **processImage(unsigned char **inputImage, int rows, int columns);
unsigned char **rectanImage (unsigned char **inputImage, int rows, int columns,int x1,int x2,int y1,int y2);



int main(void)
{
     unsigned char *inputFilename = "chest339x339.raw",
                   *outputFilename = "chest339x339out.raw";
     int rows = 339, 
         columns = 339;
     int x1=30;
     int x2=80;
     int y1=50;
     int y2=100;
         
     unsigned char **inputImage, **outputImage;

     inputImage = allocateImage(rows, columns);     
     
     inputImage = loadImage(inputFilename, rows, columns);
     outputImage = rectanImage(inputImage, rows, columns,x1,x2,y1,y2);
     saveImage(outputFilename, outputImage, rows, columns);    
     deallocateImage(inputImage, rows);
     deallocateImage(outputImage, rows);      

     return 0;
}


unsigned char **processImage(unsigned char **inputImage, int rows, int columns)

{
     int i,j;
     unsigned char **outputImage = allocateImage(rows, columns);
     double temp=0.0;
     double f=1.4;
     
     
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
             temp = inputImage[i][j]+0.4*inputImage[i][j];
             if (temp>255) temp=255;
             if (temp>0) temp=0;
			 outputImage[i][j] = (unsigned char) temp;
         }
     }
     return outputImage;
}

unsigned char **rectanImage(unsigned char **inputImage, int rows, int columns,int x1,int x2,int y1,int y2)


{
     int i,j;
     unsigned char **outputImage = allocateImage(rows, columns);
     double temp=0.0;
     double f=1.4;
     
     
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
         	if ((i>x1 && (i<x2) && (j>y1) && (j<y2)))
         	{
             temp = inputImage[i][j]+0.4*inputImage[i][j];
             if (temp>255) temp=255;
             if (temp>0) temp=0;
			 outputImage[i][j] = (unsigned char) temp;
         	}
         	else
         	{ 
		 		outputImage[i][j]=inputImage[i][j];
		 	}	
		}
     }
     return outputImage;
}




