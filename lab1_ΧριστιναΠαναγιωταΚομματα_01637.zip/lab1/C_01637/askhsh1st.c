#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define INPUT_FILENAME		"image268x324.raw"		
#define OUTPUT_FILENAME		"image268x324out.raw"	
#define ROWS				324						
#define COLUMNS				268						
#define GREYLEVELS			256						
#define OUTPUT_ROWS			ROWS				
#define OUTPUT_COLUMNS		COLUMNS					

int main(void)
{
	unsigned char	inputImage  [ROWS][COLUMNS],					
					outputImage [OUTPUT_ROWS][OUTPUT_COLUMNS];

	FILE	*inputFile,											
			*outputFile;

	int	i = 0,
		j = 0;

/*
  ------------------------------------------------------------
  LOAD IMAGE
  ------------------------------------------------------------
*/
	if ( ((inputFile = fopen(INPUT_FILENAME,"rb")) != NULL))
	{
		for  (i = 0; i < ROWS; i++)
		{
			for  (j = 0; j < COLUMNS; j++)
			{
				fscanf(inputFile, "%c", &inputImage[i][j]);
			}
		}
	} 
	else
	{
		printf("Error loading image.");
	}
	fclose(inputFile);


/*
  ------------------------------------------------------------
  PUT IMAGE PROCESSING & ANALYSIS CODE HERE
  ------------------------------------------------------------
*/

/*  Example: Copy input image to output image */

int x1,x2,y1,y2,color,k;
float f=10.0;
	x1=rand()%ROWS;
	y1=rand()%COLUMNS;
	x2=rand()%ROWS;
	y2=rand()%COLUMNS;
	color=rand()%256; 


	for (i = 0; i < ROWS; i++)
	{
		for (j = 0; j < COLUMNS; j++)
		{	
			outputImage[i][j] = (unsigned char) (127+127*cos(2*M_PI*f*(i+j)/ROWS));
		}
	}


/*
  ------------------------------------------------------------
  SAVE IMAGE
  ------------------------------------------------------------
*/
	if ( ((outputFile = fopen(OUTPUT_FILENAME,"wb")) != NULL))
	{
		for  (i = 0; i < OUTPUT_ROWS; i++)
		{
			for  (j = 0; j < OUTPUT_COLUMNS; j++)
			{
				fprintf(outputFile, "%c", outputImage[i][j]);
			}
		}
	} 
	else
	{
		printf("Error saving image.");
	}
	fclose(outputFile);

    return 0;
}
