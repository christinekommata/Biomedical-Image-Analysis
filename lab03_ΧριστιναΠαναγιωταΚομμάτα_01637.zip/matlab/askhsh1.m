%askhsh1
img=imread('chest339x339.png');
img_new=imadjust(img);
figure;
imshow(img_new);
title ('Brighter image');

max_img=max(max(img));
