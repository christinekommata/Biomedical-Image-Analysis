/*
  ------------------------------------------------------------
  ANSI C IMAGE PROCESSING TEMPLATE USING DIP LIBRARY
  by D.K. Iakovidis
  ------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "dip.h"			
#include "dipColor.h"
unsigned char **Channel(unsigned char **inputImage, int rows, int columns);
unsigned char **processImageRGB(unsigned char **inputImage, int rows, int columns);
unsigned char **rgb2gray(unsigned char **inputImage, int rows, int columns);
unsigned char **pseudoColorize(unsigned char **inputImage, int rows, int columns);
unsigned char **rgb2ohta(unsigned char **inputImage, int rows, int columns);
int main(void)
{
unsigned char *inputFilename = "melanoma269x187.raw",
                   *outputFilename = "melanoma269x187Out.raw";
     int rows = 187, 
         columns = 269;
         
     unsigned char **inputImage, **outputImage;

     inputImage = allocateImageRGB(rows, columns);     
     
     inputImage = loadImageRGB(inputFilename, rows, columns);
     //outputImage = processImageRGB(inputImage, rows, columns);
     //saveImageRGB(outputFilename, outputImage, rows, columns);    
     //outputImage = Channel(inputImage, rows, columns);
     
     //outputImage = rgb2gray(inputImage, rows, columns);
     outputImage = rgb2ohta(inputImage, rows, columns);
    //outputImage = pseudoColorize(outputImage, rows, columns);
     saveImage(outputFilename, outputImage, rows, columns);    
     //saveImageRGB(outputFilename, outputImage, rows, columns);
     deallocateImageRGB(inputImage, rows);
     deallocateImageRGB(outputImage, rows);      

     return 0;
}


unsigned char **Channel(unsigned char **inputImage, int rows, int columns)
{
     int i,j;
     unsigned char **outputImage = allocateImage(rows, columns);
     unsigned char r,g,b;
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
              r=inputImage[i][3*j];
              g=inputImage[i][3*j+1];
              b=inputImage[i][3*j+2];
              
              outputImage[i][j] =r;
         }
     }
     return outputImage;
}


unsigned char **rgb2gray(unsigned char **inputImage, int rows, int columns)
{
     int i,j;
     unsigned char **outputImage = allocateImage(rows, columns);
     unsigned char r,g,b;
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
              r=inputImage[i][3*j];
              g=inputImage[i][3*j+1];
              b=inputImage[i][3*j+2];
              
              outputImage[i][j] =(r+g+b)/3;
         }
     }
     return outputImage;
}



unsigned char **processImageRGB(unsigned char **inputImage, int rows, int columns)
{
     int i,j;
     unsigned char **outputImage = allocateImageRGB(rows, columns);
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < 3*columns; j=j+3)
         {
             outputImage[i][j] = inputImage[i][j];
             outputImage[i][j+1] = inputImage[i][j+1];
             outputImage[i][j+2] = inputImage[i][j+2];
         }
     }
     return outputImage;
}




unsigned char **pseudoColorize(unsigned char **inputImage, int rows, int columns)
{
     int i,j;
     unsigned char **outputImage = allocateImageRGB(rows, columns);
     unsigned char r[256], g[256], b[256];
     
     for (i = 0; i < 256; i++)
     {
     	if (i>200)r[i]=255; else r[i]=i;
     	g[i]=0;
     	b[i]=0;    	
     	
	 }
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < 3*columns; j=j+3)
         {
             outputImage[i][j] = r[inputImage[i][j/3]];
             outputImage[i][j+1] = g[inputImage[i][j/3]];
             outputImage[i][j+2] =b[inputImage[i][j/3]];
         }
     }
     return outputImage;
}



unsigned char **rgb2ohta(unsigned char **inputImage, int rows, int columns)
{
     int i,j;
     unsigned char **outputImage = allocateImage(rows, columns);
     unsigned char r,g,b;
     double temp, kernel[rows][columns], min=255, max=0;
     
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
              r=inputImage[i][3*j];
              g=inputImage[i][3*j+1];
              b=inputImage[i][3*j+2];
              
             //kernel[i][j] =(r-b)/2;
             kernel[i][j] =g/2-(r+b)/4;
             if (min>kernel[i][j]) min=kernel[i][j];
             if (max<kernel[i][j]) max=kernel[i][j];
         }
     }
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
         	temp=255*(kernel[i][j]-min)/(max-min);
         	outputImage[i][j] = (unsigned char) temp;	
         	
         }
     }
     
     
     
     
     return outputImage;
}
