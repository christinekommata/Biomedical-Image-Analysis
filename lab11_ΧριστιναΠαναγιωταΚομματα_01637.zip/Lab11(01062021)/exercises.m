clear all; close all;
img=imread('image268x324.png');
figure; imshow(img);

f=fft2(double(img),324, 268);
fshift=fftshift(f);

outputImage=log(1+fshift);
figure;
imshow(outputImage,[]);
rows=size(img,1);
cols=size(img,2);
sigma=16.0;
gaussian=my_gauss(sigma,rows, cols);
gaussian=normImage(gaussian);
figure; imshow(gaussian);
gaussian=double(gaussian)/255;

fshift=fshift.*(1-gaussian);
outputImage2=log(1+fshift);
figure;
imshow(outputImage2,[]);
xc=rows/2;
yc=cols/2;
funshift=circshift(fshift,[xc yc]);
inverse=ifft2(funshift); 
figure;
imshow(real(inverse),[]);


%% exercise 2
[cA,cH,cV,cD] = dwt2(img,'db1'); 
figure;
subplot(221); imshow(cA,[]);
subplot(222); imshow(cH,[]);
subplot(223); imshow(cV,[]);
subplot(224); imshow(cD,[]);

% IDWT
inverted = idwt2(cA, cH, cV, cD, 'db1'); 

% Display the magnitude of DWT
figure;
imshow(inverted,[]);

%% exercise 3

E_cA=sum(sum(cA.^2));
E_cH=sum(sum(cH.^2));
E_cV=sum(sum(cV.^2));
E_cD=sum(sum(cD.^2));

Energy=[ E_cA, E_cH, E_cV, E_cD];

