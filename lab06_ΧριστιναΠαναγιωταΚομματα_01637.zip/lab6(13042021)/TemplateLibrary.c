/*
  ------------------------------------------------------------
  ANSI C IMAGE PROCESSING TEMPLATE USING DIP LIBRARY
  by D.K. Iakovidis
  ------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "dip.h"			

unsigned char **processImage(unsigned char **inputImage, int rows, int columns);

int main(void)
{
     unsigned char *inputFilename = "image268x324.raw",
                   *outputFilename = "image268x324out.raw";
     int rows = 324, 
         columns = 268;
         
     unsigned char **inputImage, **outputImage;

     inputImage = allocateImage(rows, columns);     
     
     inputImage = loadImage(inputFilename, rows, columns);
     outputImage = processImage(inputImage, rows, columns);
     saveImage(outputFilename, outputImage, rows, columns);    
     deallocateImage(inputImage, rows);
     deallocateImage(outputImage, rows);      

     return 0;
}


unsigned char **processImage(unsigned char **inputImage, int rows, int columns)
{
     int i,j;
     double theta=40*M_PI/180;
     double j0=columns/2;
     double i0=rows/2;
     double ii, jj;
     double sx=3;
	 double sy=3;
     double dx=40;
	 double dy=60;
    
     
     
     unsigned char **outputImage = allocateImage(rows, columns);
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
             outputImage[i][j] =0 ;
			 
			// ii=cos(theta)*(i-i0)+sin(theta)*(j-j0)+i0;
			// jj=-sin(theta)*(i-i0)+cos(theta)*(j-j0)+j0;
			 
			 // ii=cos(theta)*(i-i0)-sin(theta)*(j-j0)+i0;
			 // jj=sin(theta)*(i-i0)+cos(theta)*(j-j0)+j0;
			 
			 ii=sx*cos(theta)*(i-i0)-sy*sin(theta)*(j-j0)+i0+sx*dx*cos(theta)-sy*dy*sin(theta);
			 jj=sx*sin(theta)*(i-i0)+sy*cos(theta)*(j-j0)+j0+sy*dy*cos(theta)-sx*dx*sin(theta);
			 if ((ii>=0) && (ii<rows) && (jj>=0) && (jj<columns)) outputImage[i][j] = inputImage[(int)ii][(int)jj];
         }
     }
     return outputImage;
}
