clear all; close all;
% he=imread('histology.png');
% % figure;
% % imshow(he);
% 
% % exercise 1
% %Convert to Lab colorspace
% % lab_he2=rgb2lab(he);
% 
% 
% cform=makecform('srgb2lab');
% lab_he=applycform(he, cform);
% 
% 
%   a=lab_he(:,:,2);
%   b=lab_he(:,:,3);
% %  ab=double(lab_he(:,:,2:3));
%  
%  rows=size(a,1);
%  cols=size(a,2);
%  
%  %ab=reshape(ab, rows*cols,2);
%  a=reshape(a, rows*cols,1);
%  b=reshape(b, rows*cols,1);
%  
%  k=3;
%  [cluster_idx1, cluster_center]= kmeans(b, k, 'distance', 'sqEuclidean');
%  
%  pixels_labels1=reshape(cluster_idx1, rows, cols);
%  figure;
%  imshow(pixels_labels1, []);
%  title('image labeled by cluster indices in b');
% 
%  
%  
%  % exercise 2
% %Convert to Lab colorspace
% % lab_he2=rgb2lab(he);
% 
% 
% cform=makecform('lab2srgb');
% rgb=applycform(lab_he, cform);
% 
% 
% %  a=lab_he(:,:,2);
% %  b=lab_he(:,:,3);
% %  ab=double(lab_he(:,:,2:3));
%  
%  rgb=double(reshape(rgb,rows*cols,3)); 
%  k=3;
%  [cluster_idx2, cluster_center2]= kmeans(rgb, k, 'distance', 'sqEuclidean');
%  
%  pixels_labels2=reshape(cluster_idx2, rows, cols);
%  figure;
%  imshow(pixels_labels2, []);
%  title('image labeled by cluster indices in rgb');
%  
 
 %exercise 4
 
 img=imread('bricks.jpg');
 figure; imshow(img);
 R=img(:,:,1);
 B=img(:,:,3);
 mask=[ 1 2 4;8   0  16; 32 64  128];
 lbp_img=my_lbp(B,mask);
 figure; imshow(lbp_img,[]);

 