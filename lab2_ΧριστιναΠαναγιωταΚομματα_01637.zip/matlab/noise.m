function [out]=noise(img)

% evala thn eikona se double gia na exei kalyterh akriveia
    img=double(img);    

% phra tis analogies tis eikonas pou theloume
    [rows,columns]=size(img);  
    
    out=img+randi([-255,255],rows,columns);
end
            
        
