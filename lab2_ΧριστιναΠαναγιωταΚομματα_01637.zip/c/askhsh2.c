/*
  ------------------------------------------------------------
  ANSI C IMAGE PROCESSING TEMPLATE USING DIP LIBRARY
  by D.K. Iakovidis
  ------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "dip.h"			

unsigned char **processImage(unsigned char **inputImage, int rows, int columns);
unsigned char *gaussianImage(double sigma,int rows,int columns);



int main(void)
{
     unsigned char *inputFilename = "image268x324.raw",
                   *outputFilename = "image268x324out.raw";
     int rows = 324, 
         columns = 268;
    double sigma=64.0;
         
     unsigned char **inputImage, **outputImage;

     inputImage = allocateImage(rows, columns);     
     
     inputImage = loadImage(inputFilename, rows, columns);
     outputImage = gaussianImage(sigma, rows, columns);
     saveImage(outputFilename, outputImage, rows, columns);    
     deallocateImage(inputImage, rows);
     deallocateImage(outputImage, rows);      

     return 0;
}


/*unsigned char **processImage(unsigned char **inputImage, int rows, int columns)
{
     int i,j;
     unsigned char **outputImage = allocateImage(rows, columns);
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
             outputImage[i][j] = inputImage[i][j];
         }
     }
     return outputImage;
}*/

unsigned char *gaussianImage(double sigma,int rows,int columns)
{
	int i,j;
	unsigned char **outputImage = allocateImage(rows, columns);
	double min=255.0;
	double max=0.0;
	double xc=rows/2;
	double yc=columns/2;
	double kernel[rows][columns];
	
	for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
         	kernel[i][j]=(1/(2*M_PI*pow(sigma,2)))*exp(-(pow(i-xc,2)/rows+pow(j-yc,2)/columns)/(2*sigma*sigma));
         	if (max< kernel[i][j]) max=kernel[i][j];
         	if (min> kernel[i][j]) min=kernel[i][j];
         }
     }
     
     for (i=0; i<rows; i++)
     {
     	for (j=0; j<columns; j++)
     	{
     		kernel[i][j]= (kernel[i][j]-min)/(max-min);
     		outputImage[i][j]=(unsigned char) (255*kernel[i][j]);
		 }
	 }
     
     return outputImage;
}
