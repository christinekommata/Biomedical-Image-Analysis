img=imread('image268x324.png');
rotated_img=imrotate(img,90);
figure; imshow(img)
figure; imshow(rotated_img)

resized_img=imresize(img, [50,50]);
figure; imshow(resized_img)

translated_img=imtranslate(img, [15 25]);
figure; imshow(translated_img)

img2=imtranslate(imresize(rotated_img, 0.5), [15 25]);
figure; imshow(img2)
%%
img3=fliplr(img);
figure; imshow(img3)
