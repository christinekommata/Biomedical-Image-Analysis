/*
  ------------------------------------------------------------
  ANSI C IMAGE PROCESSING TEMPLATE USING DIP LIBRARY
  by D.K. Iakovidis
  ------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "dip.h"	
#include "dipColor.h"			

unsigned char **processImage(unsigned char **inputImage, int rows, int columns);
double MAX(double r, double g, double b);
double MIN(double r, double g, double b);
void rgb2hsv(double r, double g, double b, double *h, double *s, double *v);
void hsv2rgb(double *r, double *g, double *b, double h, double s, double v);
unsigned char **Hue(unsigned char **inputImage, int rows, int columns);
unsigned char **quantize(unsigned char **inputImage,int rows, int cols,int levels);
long *equalizedHist(unsigned char **inputImage,int rows,int cols);


int main(void)
{
    unsigned char *inputFilename = "angioectasia-P2-6-360x360.raw",
                   *outputFilename = "angioectasia-P2-6-360x360hsv.raw",
				   *outputFilename2 = "angioectasia_rgb_360x360.raw",
				   *outputFilename3 = "angioectasia_hue_360x360.raw",
				   *outputFilename4 = "angioectasia_quantum_hue_360x360.raw";
     int i,j, rows = 360, columns=360;
         
    
         
     unsigned char **inputImage, **outputImage, **outputImage2, **channelHue, **quantumHue;
     double r,g,b,h,s,v, r1,g1,b1,temp;
	
     // outputImage = processImage(inputImage, rows, columns);
     inputImage=allocateImageRGB(rows,columns);
     inputImage=loadImageRGB(inputFilename, rows,columns);
     outputImage=allocateImageRGB(rows,columns);
     outputImage2=allocateImageRGB(rows,columns);
     long int *qh_hist, h_hist[256];
     for (i=0; i<256;i++)
     {
     	h_hist[i]=0;
     	
	 }
     
     for (i=0;i<rows;i++)
     {
     	 for (j=0;j<3*columns;j=j+3)
     	 {
     	 	r=(double)(inputImage[i][j]/255.0);
     	 	g=(double)(inputImage[i][j+1]/255.0);
     	 	b=(double)(inputImage[i][j+2]/255.0);
     	 	
     	 	
     	 	rgb2hsv(r,g,b,&h,&s,&v);
     	 	
     	 	outputImage[i][j] = (unsigned char)  (255.0*(h/360.0));
     	 	outputImage[i][j+1] = (unsigned char)  (255.0*s);
     	 	temp=(255.0*v+30);
		    if (temp>255) temp=255;
		    if (temp<0) temp=0;
		    outputImage[i][j+2] = (unsigned char)(temp);
			h_hist[(unsigned char)(255*(h/360)) ]=h_hist[(unsigned char)(255*(h/360)) ]+1;
			
     	 	hsv2rgb(&r1,&g1,&b1, h,s,temp/255);// prepei na dothei to temp kanonikopoihmeno gia na epistrepsei thn eikona me 
     	 	// aukshmenh fwteinothta
     	    outputImage2[i][j] = (unsigned char)  (255.0*r1);
     	 	outputImage2[i][j+1] = (unsigned char)  (255.0*g1);
     	 	outputImage2[i][j+2] = (unsigned char)  (255.0*b1);
     	 	
		  }
     	
	 }
	 
	 for(i=0;i<256;i++)
	 {
	 	printf(" %u ", h_hist[i]);
	 }
     
     channelHue=Hue(outputImage, rows,columns);
     quantumHue=quantize(channelHue,rows,columns,4);
     qh_hist=equalizedHist(quantumHue,rows,columns);
     
     
      for(i=0;i<256;i++)
	 {
	 	printf(" %u ", qh_hist[i]);
	 }
     
     
     saveImageRGB(outputFilename, outputImage, rows, columns);  
    saveImageRGB(outputFilename2, outputImage2, rows, columns); 
	 saveImage(outputFilename3, channelHue, rows, columns);   
	  saveImage(outputFilename4, quantumHue, rows, columns);   
     deallocateImageRGB(inputImage, rows);
     deallocateImageRGB(outputImage, rows);     
   //  deallocateImageRGB(outputImage2, rows);     

     return 0;
}

void rgb2hsv(double r, double g, double b, double *h, double *s, double *v)
{
	double min, max, delta;
	min=MIN(r,g,b);
	max=MAX(r,g,b);
	
	*v=max;// value
	delta=max-min;
	
	if (max!=0) 
	{
	*s=delta/max; //saturation
	} 
	else
	{
		*s=0;
		*h=-1;// undefined hue
		return;
	}
	
	if (r==max)*h=(g-b)/delta;
	if (g==max)*h=2+(b-r)/delta;
	if (b==max)*h=4+(r-g)/delta;
	
	*h*=60;//degrees
	if (*h<0) *h+=360;
	return;
}


unsigned char **processImage(unsigned char **inputImage, int rows, int columns)
{
     int i,j;
     unsigned char **outputImage = allocateImage(rows, columns);
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
             outputImage[i][j] = inputImage[i][j];
         }
     }
     return outputImage;
}


double MAX(double r, double g, double b)
{
       double max;
       if (r>g) max = r; else max = g;
       if (b>max) max = b;
       return max;
}


double MIN(double r, double g, double b)
{
       double min;
       if (r>g) min = g; else min = r;
       if (b<min) min = b;
       return min;
}


void hsv2rgb(double *r, double *g, double *b, double h, double s, double v)
{

	int i;
	double f,q,p,t;
	if(s==0)
	{
		*r=*g=*b=v;
		return;
	}

	h/=60;
	i=floor(h);
	f=h-i;
	p=v*(1-s);
	q=v*(1-s*f);
	t=v*(1-s*(1-f));
	switch(i){
		case 0:
				*r=v;
				*g=t;
				*b=p;
				break;
			
			
		case 1:
				*r=q;
				*g=v;
				*b=p;
				break;
		case 2:
			
			    *r=p;
				*g=q;
				*b=v;
				break;
	    case 4:
	    		*r=t;
				*g=p;
				*b=v;
				break;
		 default:
			    *r=v;
				*g=p;
				*b=q;
				break;
				
	}


}

unsigned char **Hue(unsigned char **inputImage, int rows, int columns)
{
	
	int i,j;
     unsigned char **outputImage = allocateImage(rows, columns);
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < columns; j++)
         {
             outputImage[i][j] = inputImage[i][j*3];
              
         }
     }
     return outputImage;
}
	
unsigned char **quantize(unsigned char **inputImage,int rows, int cols,int levels)
{
     int i,j;
     unsigned char **outputImage = allocateImage(rows, cols);

     float q = 255.0f/levels;
     
     for (i = 0; i < rows; i++)
     {
         for (j = 0; j < cols; j++)
         {
             outputImage[i][j] = (unsigned char)(floor(inputImage[i][j]/q)*q+q/2);
         }
     }
     return outputImage;
}	


long *equalizedHist(unsigned char **inputImage,int rows,int cols)
{
    long *h =(long *)malloc(256*sizeof(long));
    int i,j;
    for(i=0;i<256;i++){
        h[i]=0;
    }
    for(i=0;i<rows;i++){
        for(j=0;j<cols;j++){
            h[inputImage[i][j]]++;
        }
    }
    return h;
}




