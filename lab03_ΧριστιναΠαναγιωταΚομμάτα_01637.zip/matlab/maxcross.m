function [out]=maxcross(img)
   
    [rows,columns]=size(img);
    
    % search image for max gray level value and store its coordinates
    max_value=0;
    for i=1:rows
        for j=1:columns
            if(max_value<img(i,j))
                max_value=img(i,j);
        		max_i=i;
        		max_j=j;
            end
        end
    end

    % generate a black (0) 10x10 cross whose center is (max_i,max_j)
    for i=1:rows
        for j=1:columns
        	if (i==max_i) && (j>=max_j-10) && (j<=max_j+10) || (j==max_j) && (i>=max_i-10) && (i<=max_i+10)
               	out(i,j)=0;
            else
                out(i,j)=img(i,j);
            end       
        end
    end

end