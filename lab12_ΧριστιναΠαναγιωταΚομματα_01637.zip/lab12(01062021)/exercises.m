clear all; close all;

%% exercise 1
%read dicom info
info=dicominfo('CT-MONO2-16-ankle.dcm');

%read dicom image 
[image, map]=dicomread('CT-MONO2-16-ankle.dcm');
% 
%show image
figure;
imshow(image, map);



%% exercise 2
info2=dicominfo('US-PAL-8-10x-echo.dcm');
[image2, map2]=dicomread('US-PAL-8-10x-echo.dcm');
figure; montage(image2, map2);
I=image2(:,:,:,3);
figure; imshow(I, map2);

%% exercise 3
folder='C:\Users\digest_article\';
S1=dir(fullfile(folder,'*.dcm'));

for i=1:length(S1)
    dcm_list{i}=dicomread(fullfile(folder,S1(i).name));
    img_dcm=dcm_list{i};
    img_dcm=mat2gray(img_dcm);
    
    %process image
    
    imwrite(img_dcm,strcat('C:\Users\png images\brain0',int2str(i),'.png'));
    
   
    
end 

%%
file_in='.\US-PAL-8-10x-echo.dcm';
info3=dicominfo('US-PAL-8-10x-echo.dcm');
file_out='.\US-PAL-8-10x-echo2.dcm';
info4=dicominfo('US-PAL-8-10x-echo2.dcm');

dicomanon(file_in, file_out);

