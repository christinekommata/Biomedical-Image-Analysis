%sunarthsh gia thn eikona 

function [out]=normImage(img)

norm_img= 255*(img-min(min(img)))/(max(max(img))-min(min(img)));
out=uint8(norm_img);
end